import './TextInput.css';

export const TextInput = ({ onChange }) => (
	<input className="text-input" onChange={onChange}></input>
);
