const App = () => {
    return (
        <div className="App">
            <h1>React Hooks exercise starter</h1>
        </div>
    );
};

export default App;
