import './App.css'

export const App = () => {
    return (
        <div>
            <h1>Hello World!</h1>
        </div>
    )
}