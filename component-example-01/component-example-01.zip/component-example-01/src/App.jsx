import './App.css';

export const App = () => {
    const hello = "Hello Wincer!";

    return (
        <main>
            <h1>{hello}</h1>
        </main>
    );
};