export const tea = {
    name: "Tea",
    imgUrl: "https://media.wincacademy.nl/tea.jpeg",
    imgAlt: "Picture of a cup of tea"
};

export const coffee = {
    name: "Coffee",
    imgUrl: "https://media.wincacademy.nl/coffee.jpeg",
    imgAlt: "Picture of a cup of coffee"
};