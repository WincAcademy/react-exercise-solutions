export const tea = {
	name: "Tea",
	imgUrl: "https://media.wincacademy.nl/tea.jpeg",
	alt: "Picture of a cup of tea"
};

export const coffee = {
	name: "Coffee",
	imgUrl: "https://media.wincacademy.nl/coffee.jpeg",
	alt: "Picture of a cup of coffee"
};